ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/#:~:text=On%20March%2013%2C%202020%2C%20by)
2. attachment_2_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/)
3. attachment_3_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/#:~:text=SACRAMENTO%20%E2%80%93%20As%20part%20of)
4. attachment_5_https___www_portofhueneme_org_.pdf (original URL: https://www.portofhueneme.org/coronavirus-update/#:~:text=May%2021%2C%202020%20%E2%80%93%20On)
5. attachment_6_https___abc7_com_ventura_count.pdf (original URL: https://abc7.com/ventura-county-beaches-july-4-2020-4th-of-weekend-open-for/6286107/#:~:text=Ventura%20County%20beaches%20to%20close)

Generated on: 2025-03-14T11:15:00.205Z