ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (9 total):
1. source_1_govinfo.gov.pdf (original URL: https://www.govinfo.gov/content/pkg/FR-2020-03-18/pdf/2020-05794.pdf)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-gavin-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/19/governor-gavin-newsom-issues-stay-at-home-order/)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/public-health-orders.aspx)
5. source_5_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/SAFER-ECONOMY.aspx)
6. source_6_vcemergency.com.pdf (original URL: https://vcemergency.com/)
7. source_7_s29622.pcdn.co.pdf (original URL: https://s29622.pcdn.co/wp-content/uploads/2020/03/03.20.20-Stay-Well-at-Home-Order.pdf)
8. source_8_s29622.pcdn.co.pdf (original URL: https://s29622.pcdn.co/wp-content/uploads/2020/05/5.7.20-Safely-Reopening-VC-Order.pdf)
9. source_9_s29622.pcdn.co.pdf (original URL: https://s29622.pcdn.co/wp-content/uploads/2020/07/7.13.20-Ventura-County-Order.pdf)

Generated on: 2025-05-02T13:21:15.662Z