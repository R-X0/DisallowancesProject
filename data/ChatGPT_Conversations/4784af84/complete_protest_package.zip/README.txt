ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (12 total):
1. source_1_govinfo.gov.pdf (original URL: https://www.govinfo.gov/content/pkg/FR-2020-03-18/pdf/2020-05794.pdf)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/Proclamation-of-Emergency-3-4-20.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/Stay-Home-Order.aspx)
5. source_5_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/VCHealthEmergency.pdf)
6. source_6_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/03092020%20Stay%20Well%20Order.pdf)
7. source_7_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/VCHealthOrderUpdates-MarApr2020.pdf)
8. source_8_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/SafelyReopening-VC-5.7.20.pdf)
9. source_9_docs.vcrma.org.pdf (original URL: https://docs.vcrma.org/eviction-moratorium-2020.pdf)
10. source_10_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/docs/LocalEmergencyProclamation.pdf)
11. source_11_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/docs/CamarilloEvictionMoratorium.pdf)
12. source_12_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/docs/Resolution2020-63.pdf)

Generated on: 2025-05-02T08:13:19.621Z