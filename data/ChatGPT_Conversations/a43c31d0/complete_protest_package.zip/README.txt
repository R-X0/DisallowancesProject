ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (10 total):
1. source_1_govinfo.gov.pdf (original URL: https://www.govinfo.gov/content/pkg/FR-2020-03-18/pdf/2020-05794.pdf)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/Proclamation-of-State-of-Emergency-3.4.20.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/EO-N-33-20-COVID-19-HEALTH-ORDER-03.19.2020.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/Guidance-for-Closure_of_Sectors_in_Response_to_COVID-19_07-13-2020.pdf)
5. source_5_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/BlueprintFAQ.aspx)
6. source_6_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/Health-Order-3.12.20.pdf)
7. source_7_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-20_StayWellAtHomeOrder.pdf)
8. source_8_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/PublicHealthOrder-2020-07-13.pdf)
9. source_9_cityofcamarillo.org.pdf (original URL: https://cityofcamarillo.org/DocumentCenter/View/763/Proclamation-of-Local-Emergency-PDF)
10. source_10_cityofcamarillo.org.pdf (original URL: https://cityofcamarillo.org/DocumentCenter/View/1622/Resolution-No-2020-63-Outdoor-Dining-PDF)

Generated on: 2025-05-02T13:05:20.131Z