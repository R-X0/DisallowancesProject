ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (8 total):
1. source_1_bidenwhitehouse.archives.gov.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/Order-of-the-State-Public-Health-Officer-Beyond-Blueprint-6-11-2021.aspx)
5. source_5_cms7files.revize.com.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf)
6. source_6_aagla.org.pdf (original URL: https://aagla.org/wp-content/uploads/2020/06/extension-or-the-ordinance.pdf)
7. source_7_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/VC_Roadmap_to_Reopening_rev052120f.pdf)
8. source_8_portofhueneme.org.pdf (original URL: https://www.portofhueneme.org/coronavirus-update/)

Generated on: 2025-05-05T03:25:41.933Z