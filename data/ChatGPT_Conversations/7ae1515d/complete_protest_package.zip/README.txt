ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (6 total):
1. source_1_govinfo.gov.pdf (original URL: https://www.govinfo.gov/content/pkg/FR-2020-03-18/pdf/2020-05794.pdf)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/Proclamation-of-Emergency-3.4.20.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf)
4. source_4_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/03.12.20_VCHealthEmergency.pdf)
5. source_5_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-20_StayWellAtHomeOrder.pdf)
6. source_6_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-05-07_SafelyReopeningOrder.pdf)

Generated on: 2025-05-02T13:31:34.052Z