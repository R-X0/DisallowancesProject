ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (11 total):
1. source_1_federalregister.gov.pdf (original URL: https://www.federalregister.gov/documents/2020/03/18/2020-05794/national-emergency-concerning-the-novel-coronavirus-disease-covid-19-outbreak)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.4.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-covid-19.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/HealthOfficerOrder5-7-2020.pdf)
5. source_5_vcemergency.com.pdf (original URL: https://vcemergency.com/wp-content/uploads/2020/03/VC-Declaration-of-Health-Emergency.pdf)
6. source_6_vcemergency.com.pdf (original URL: https://vcemergency.com/wp-content/uploads/2020/03/HealthOfficerOrderStayWellAtHome.pdf)
7. source_7_vcemergency.com.pdf (original URL: https://vcemergency.com/wp-content/uploads/2020/04/Second-Amended-StayWellAtHomeOrder4.20.20.pdf)
8. source_8_vcemergency.com.pdf (original URL: https://vcemergency.com/wp-content/uploads/2020/05/Extended-StayWell-VC-Order-5.7.20.pdf)
9. source_9_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/city_council/local_emergency_2020.php)
10. source_10_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/local-emergency-order-20-2)
11. source_11_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/temporary-outdoor-dining-resolution-2020-63)

Generated on: 2025-05-02T09:01:49.034Z