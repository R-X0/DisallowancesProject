ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (9 total):
1. source_1_govinfo.gov.pdf (original URL: https://www.govinfo.gov/content/pkg/FR-2020-03-18/pdf/2020-05794.pdf)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.4.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/19/governor-gavin-newsom-issues-stay-at-home-order)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/Stay-Home-Order.aspx)
5. source_5_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/Official-Documentation/VC_HealthEmergency_Declaration_3.12.20.pdf)
6. source_6_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/StayWellAtHomeOrder.pdf)
7. source_7_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/5.7.20_PublicHealthOrder.pdf)
8. source_8_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/government/departments/city_manager/emergency_management/covid-19.php)
9. source_9_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org)

Generated on: 2025-05-02T08:40:01.193Z