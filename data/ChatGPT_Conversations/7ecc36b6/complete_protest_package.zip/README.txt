ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (6 total):
1. source_1_govinfo.gov.pdf (original URL: https://www.govinfo.gov/content/pkg/FR-2020-03-18/pdf/2020-05794.pdf)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.4.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/SHO%20Order%205-7-2020.pdf)
5. source_5_vcpublichealth.org.pdf (original URL: https://vcpublichealth.org)
6. source_6_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/docs/Resolution2020-63OutdoorDining.pdf)

Generated on: 2025-05-02T08:28:06.303Z