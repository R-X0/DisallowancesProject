ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/#:~:text=On%20March%2013)
2. attachment_2_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/#:~:text=SACRAMENTO%20%E2%80%93%20As%20part)
3. attachment_3_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf#:~:text=March%2019)
4. attachment_4_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8-28-20_Order-Plan-Reducing-COVID19-Adjusting-Permitted-Sectors-Signed.pdf#:~:text=)
5. attachment_5_https___cms7files_revize_com_c.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf#:~:text=RESOLUTION%20NO.%202020)
6. attachment_6_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/#:~:text=SACRAMENTO%20%E2%80%93%20As%20part...)

Generated on: 2025-03-19T10:48:01.888Z