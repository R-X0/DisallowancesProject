ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/#:~:text=On%20March%2013%2C%202020%2C%20by)
2. attachment_2_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/#:~:text=SACRAMENTO%20%E2%80%93%20As%20part%20of)
3. attachment_3_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf#:~:text=March%2019%2C%202020%20To%20protect)
4. attachment_4_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8-28-20_Order-Plan-Reducing-COVID19-Adjusting-Permitted-Sectors-Signed.pdf#:~:text=with%20Executive%20Order%20N-60-20)
5. attachment_5_https___www_cityofmontclair_or.pdf (original URL: https://www.cityofmontclair.org/december-5-2020-regional-stay-at-home-order/#:~:text=Late%20Friday%2C%20December%204%2C%202020%2C))
6. attachment_6_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2021/06/6.11.21-EO-N-07-21-signed.pdf)
7. attachment_7_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/Order-of-the-State-Public-Health-Officer-Beyond-Blueprint-6-11-2021.aspx)
8. attachment_8_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/))
9. attachment_9_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/VC_Public_Health_Officer_Order_10-06-2020.pdf)
10. attachment_10_https___abc7_com_ventura_count.pdf (original URL: https://abc7.com/ventura-county-beaches-july-4-2020-4th-of-weekend-open-for/6286107/#:~:text=Ventura%20County%20beaches%20to%20close)
11. attachment_11_https___members_aagla_org_news.pdf (original URL: https://members.aagla.org/news/temporary-eviction-moratoriums--novel-coronavirus-covid-19))
12. attachment_12_https___www_camhealth_com__.pdf (original URL: https://www.camhealth.com/))
13. attachment_13_https___www_camhealth_com_city.pdf (original URL: https://www.camhealth.com/city-of-camarillo-past-press-releases)
14. attachment_14_https___cms7files_revize_com_c.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf#:~:text=RESOLUTION%20NO.%202020-63)
15. attachment_15_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/)

Generated on: 2025-03-19T12:57:04.178Z