ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (7 total):
1. source_1_federalregister.gov.pdf (original URL: https://www.federalregister.gov/documents/2020/03/18/2020-05794/proclamation-9994-declaring-a-national-emergency-concerning-the-novel-coronavirus-disease-covid-19)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.4.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/Executive-Order-N-33-20.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/SHO-Order-05-07-2020.pdf)
5. source_5_vcemergency.com.pdf (original URL: https://www.vcemergency.com/wp-content/uploads/2020/03/03.12.20-Declaration-of-Local-Health-Emergency.pdf)
6. source_6_vcemergency.com.pdf (original URL: https://www.vcemergency.com/wp-content/uploads/2020/03/3.20.20-Stay-Well-At-Home-Order.pdf)
7. source_7_vcemergency.com.pdf (original URL: https://www.vcemergency.com/wp-content/uploads/2020/04/VC-Public-Health-Orders-Mar-April-2020.pdf)

Generated on: 2025-05-02T09:22:24.824Z