ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (15 total):
1. source_1_federalregister.gov.pdf (original URL: https://www.federalregister.gov/documents/2020/03/18/2020-05794)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.4.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/03.19.20-executive-order-n-33-20.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/Public-Health-Officer-Order-05-07-2020.aspx)
5. source_5_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-12_VCHealthEmergency.pdf)
6. source_6_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-17_PublicHealthOrder.pdf)
7. source_7_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-20_StayWellAtHomeOrder.pdf)
8. source_8_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-31_ExtensionOrder.pdf)
9. source_9_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-04-09_order.pdf)
10. source_10_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-04-20_order.pdf)
11. source_11_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-05-07_SafelyReopeningVC.pdf)
12. source_12_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-04-22_evictionmoratorium.pdf)
13. source_13_cityofcamarillo.org.pdf (original URL: https://cityofcamarillo.org/docs/local_emergency_3.13.20.pdf)
14. source_14_cityofcamarillo.org.pdf (original URL: https://cityofcamarillo.org/docs/evictionmoratorium_3.18.20.pdf)
15. source_15_cityofcamarillo.org.pdf (original URL: https://cityofcamarillo.org/docs/resolution2020-63OutdoorDining_6.10.20.pdf)

Generated on: 2025-05-02T12:43:32.507Z