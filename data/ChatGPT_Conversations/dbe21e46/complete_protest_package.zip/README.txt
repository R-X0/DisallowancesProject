ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (5 total):
1. source_1_bidenwhitehouse.archives.gov.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/)
2. source_2_cdc.gov.pdf (original URL: https://www.cdc.gov/quarantine/masks/mask-travel-guidance.html)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/)
4. source_4_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/VC_BOS_Proclamation_of_Local_Health_Emergency_03-12-2020.pdf)
5. source_5_cms7files.revize.com.pdf (original URL: https://cms7files.revize.com/camarilloca/camarillo_emergency_proclamation_03132020.pdf)

Generated on: 2025-05-05T20:01:31.671Z