ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (8 total):
1. source_1_federalregister.gov.pdf (original URL: https://www.federalregister.gov/documents/2020/03/18/2020-05794/proclamation-9994-declaring-a-national-emergency-concerning-the-novel-coronavirus-disease-covid-19)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/19/governor-gavin-newsom-issues-stay-at-home-order/)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/PublicHealthGuidance.aspx)
5. source_5_ventura.org.pdf (original URL: https://www.ventura.org/public-health/)
6. source_6_docs.vcrma.org.pdf (original URL: https://docs.vcrma.org/images/pdf/ordinances/2020/ord_4563.pdf)
7. source_7_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/departments/city_manager/emergency_preparedness/covid-19_information.php)
8. source_8_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/files/complaints/Resolution2020_63.pdf)

Generated on: 2025-05-02T09:09:53.588Z