ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (11 total):
1. source_1_federalregister.gov.pdf (original URL: https://www.federalregister.gov/documents/2020/03/18/2020-05794/proclamation-9994-declaring-a-national-emergency-concerning-the-novel-coronavirus-disease-covid-19-outbreak)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.4.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-executive-order-n-33-20.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/Stay-Home-Order.aspx)
5. source_5_vcpublichealth.org.pdf (original URL: https://vcpublichealth.org/covid19/docs/03.20.20-StayWellAtHomeOrder.pdf)
6. source_6_vcpublichealth.org.pdf (original URL: https://vcpublichealth.org/covid19/docs/04.20.20-ExtendedHealthOrder.pdf)
7. source_7_vcpublichealth.org.pdf (original URL: https://vcpublichealth.org/covid19/docs/05.07.20-SafelyReopening.pdf)
8. source_8_docs.vcrma.org.pdf (original URL: https://docs.vcrma.org/images/pdf/ordinances/urgency_ordinance_no._4563.pdf)
9. source_9_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/documents/EOC-Order-20-1.pdf)
10. source_10_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/documents/EOC-Order-20-2.pdf)
11. source_11_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/documents/2020-63-OutdoorDining.pdf)

Generated on: 2025-05-02T12:30:33.884Z