ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/#:~:text=On%20March%2013%2C%202020%2C)
2. attachment_2_https___gov_ca_gov.pdf (original URL: https://gov.ca.gov)
3. attachment_3_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/))
4. attachment_4_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/VC_Public_Health_Officer_Order_10-06-2020.pdf))
5. attachment_5_https___www_camhealth_com_city.pdf (original URL: https://www.camhealth.com/city-of-camarillo-past-press-releases)
6. attachment_6_https___cms7files_revize_com_c.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf))
7. attachment_7_https___members_aagla_org_news.pdf (original URL: https://members.aagla.org/news/temporary-eviction-moratoriums--novel-coronavirus-covid-19))

Generated on: 2025-03-14T11:58:51.498Z