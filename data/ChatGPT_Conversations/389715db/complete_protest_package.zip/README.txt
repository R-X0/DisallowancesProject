ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (12 total):
1. source_1_federalregister.gov.pdf (original URL: https://www.federalregister.gov/documents/2020/03/18/2020-05794/proclamation-9994-declaring-a-national-emergency-concerning-the-covid-19-outbreak)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/03.04.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/03.19.20-executive-order-n-33-20.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPHDocumentLibrary/COVID-19/SHO%20Order%205-7-2020.pdf)
5. source_5_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/03.12.20-LocalHealthEmergency.pdf)
6. source_6_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/03.20.20-StayWellAtHomeOrder.pdf)
7. source_7_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/03.31.20-VCHealthOrder.pdf)
8. source_8_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/05.07.20-SafelyReopeningOrder.pdf)
9. source_9_docs.vcrma.org.pdf (original URL: https://docs.vcrma.org/urgency-ordinance-4563)
10. source_10_cityofcamarillo.org.pdf (original URL: https://cityofcamarillo.org/docs/03.13.20-EmergencyProclamation.pdf)
11. source_11_cityofcamarillo.org.pdf (original URL: https://cityofcamarillo.org/docs/03.18.20-EOCOrder20-2.pdf)
12. source_12_cityofcamarillo.org.pdf (original URL: https://cityofcamarillo.org/docs/06.10.20-Resolution2020-63.pdf)

Generated on: 2025-05-02T14:45:32.418Z