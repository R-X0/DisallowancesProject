ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (4 total):
1. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/04)
2. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf)
3. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8-28-20_Order-Plan-Reducing-COVID19-Adjusting-Permitted-Sectors-Signed.pdf)
4. source_5_ventura.org.pdf (original URL: https://www.ventura.org/covid19)

Generated on: 2025-04-08T07:32:58.260Z