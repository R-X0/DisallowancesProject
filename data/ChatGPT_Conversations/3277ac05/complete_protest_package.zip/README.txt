ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/#:~:text=On%20March%2013%2C%202020%2C)
2. attachment_2_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/#:~:text=SACRAMENTO)
3. attachment_3_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf#:~:text=March%2019%2C%202020%20To%20protect)
4. attachment_5_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8-28-20_Order-Plan-Reducing-COVID19-Adjusting-Permitted-Sectors-Signed.pdf#:~:text=)
5. attachment_6_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/supplement-regional-stay-at-home-order.aspx))
6. attachment_7_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/VC_Public_Health_Officer_Order_03-20-2020.pdf)
7. attachment_8_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/))
8. attachment_9_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/VC_Public_Health_Officer_Order_10-06-2020.pdf#:~:text=one%20based%20on%20a%20monitoring)
9. attachment_10_https___aagla_org_wp_content_u.pdf (original URL: https://aagla.org/wp-content/uploads/2020/06/extension-or-the-ordinance.pdf#:~:text=7)
10. attachment_11_https___www_camhealth_com_city.pdf (original URL: https://www.camhealth.com/city-of-camarillo-past-press-releases#:~:text=Camarillo%20City%20Hall%2C%20Public%20Works)

Generated on: 2025-03-19T14:15:17.384Z