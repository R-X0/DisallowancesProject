ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (4 total):
1. source_1_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf)
3. source_3_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/VC_Roadmap_to_Reopening_rev052120f.pdf)
4. source_4_cms7files.revize.com.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf)

Generated on: 2025-04-08T07:07:54.062Z