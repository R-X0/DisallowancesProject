ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/#:~:text=On%20March%2013)
2. attachment_2_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/#:~:text=SACRAMENTO%E2%80%93As%20part%20of%20the%20state)
3. attachment_3_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf#:~:text=March%2019)
4. attachment_4_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8-28-20_Order-Plan-Reducing-COVID19-Adjusting-Permitted-Sectors-Signed.pdf#:~:text=to%20the%20end%20of%20the)
5. attachment_5_https___www_gov_ca_gov_2020_08.pdf (original URL: https://www.gov.ca.gov/2020/08/28/governor-newsom-unveils-blueprint-for-a-safer-economy-a-statewide-stringent-and-slow-plan-for-living-with-covid-19/#:~:text=SACRAMENTO%20%E2%80%93%20Governor%20Gavin%20Newsom)
6. attachment_6_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2021/06/6.11.21-EO-N-07-21-signed.pdf#:~:text=1%29%20Executive%20Order%20N)
7. attachment_7_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/VC_Public_Health_Officer_Order_10-06-2020.pdf#:~:text=PUBLIC%20HEALTH%20AND%20UNDER%20THE)
8. attachment_8_https___aagla_org_wp_content_u.pdf (original URL: https://aagla.org/wp-content/uploads/2020/06/extension-or-the-ordinance.pdf#:~:text=7))
9. attachment_9_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/VC_Public_Health_Officer_Order_10-06-2020.pdf#:~:text=with%20Executive%20Order%20N-60-20)
10. attachment_10_https___members_aagla_org_news.pdf (original URL: https://members.aagla.org/news/temporary-eviction-moratoriums--novel-coronavirus-covid-19#:~:text=Temporary%20Eviction%20Moratoriums))
11. attachment_11_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/#:~:text=SACRAMENTO%E2%80%93)
12. attachment_12_https___vcportal_ventura_org.pdf (original URL: https://vcportal.ventura.org)
13. attachment_13_https___camhealth_com.pdf (original URL: https://camhealth.com)

Generated on: 2025-03-08T02:51:35.220Z