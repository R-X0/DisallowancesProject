ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (13 total):
1. source_1_federalregister.gov.pdf (original URL: https://www.federalregister.gov/documents/2020/03/18/2020-05794)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.4.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/2020/03/19/governor-gavin-newsom-issues-stay-at-home-order/)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/StayHomeOrder.aspx)
5. source_5_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-12-Ventura-County-Declaration-of-Emergency.pdf)
6. source_6_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-17-Ventura-County-Public-Health-Order.pdf)
7. source_7_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-03-20-StayWellAtHomeOrder.pdf)
8. source_8_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-04-09-ExtendedOrder.pdf)
9. source_9_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-05-07-SafelyReopeningVC.pdf)
10. source_10_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/covid19/docs/2020-04-22-OrdinanceNo4563.pdf)
11. source_11_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/DocLibrary/EOC-Order-20-1.pdf)
12. source_12_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/DocLibrary/EOC-Order-20-2.pdf)
13. source_13_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/DocLibrary/Resolution-2020-63.pdf)

Generated on: 2025-05-02T09:53:26.076Z