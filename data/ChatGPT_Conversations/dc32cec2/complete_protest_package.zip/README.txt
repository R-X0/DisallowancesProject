ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (15 total):
1. source_1_govinfo.gov.pdf (original URL: https://www.govinfo.gov/content/pkg/FR-2020-03-18/pdf/2020-05794.pdf)
2. source_2_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.4.20-Coronavirus-SOE-Proclamation.pdf)
3. source_3_gov.ca.gov.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/EO-N-33-20.pdf)
4. source_4_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/HealthOfficerOrder-5-7-2020.pdf)
5. source_5_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/7-13-20-Statewide-Public-Health-Order.pdf)
6. source_6_cdph.ca.gov.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8.28.20-Blueprint-Plan.pdf)
7. source_7_cdn.ventura.org.pdf (original URL: https://cdn.ventura.org/wp-content/uploads/2020/03/3.12.20-VC-Local-Health-Emergency.pdf)
8. source_8_cdn.ventura.org.pdf (original URL: https://cdn.ventura.org/wp-content/uploads/2020/03/3.20.20-VC-Stay-Well-At-Home-Order.pdf)
9. source_9_cdn.ventura.org.pdf (original URL: https://cdn.ventura.org/wp-content/uploads/2020/05/5.7.20-Ventura-Safely-Reopening-Order.pdf)
10. source_10_cdn.ventura.org.pdf (original URL: https://cdn.ventura.org/wp-content/uploads/2020/06/6.30.20-4th-of-July-Beach-Closure-Order.pdf)
11. source_11_cdn.ventura.org.pdf (original URL: https://cdn.ventura.org/wp-content/uploads/2020/07/7.13.20-VC-Local-Rollback-Order.pdf)
12. source_12_vcportal.ventura.org.pdf (original URL: https://vcportal.ventura.org/boardofsupers/meetings/2020/2020-03-31/Item%206%20Ordinance%204563.pdf)
13. source_13_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/documents/EOC_Order_20-1.pdf)
14. source_14_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/documents/EOC_Order_20-2.pdf)
15. source_15_cityofcamarillo.org.pdf (original URL: https://www.cityofcamarillo.org/documents/Resolution2020-63-OutdoorDining.pdf)

Generated on: 2025-05-02T13:43:42.007Z