ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter in PDF format)

Attachments (29 total):
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/#:~:text=On%20March%2013%2C%202020%2C%20by)
2. attachment_2_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/#:~:text=SACRAMENTO%20%E2%80%93%20As%20part%20of)
3. attachment_3_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf#:~:text=March%2019%2C%202020%20To%20protect)
4. attachment_4_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8-28-20_Order-Plan-Reducing-COVID19-Adjusting-Permitted-Sectors-Signed.pdf#:~:text=with%20Executive%20Order%20N)
5. attachment_5_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8-28-20_Order-Plan-Reducing-COVID19-Adjusting-Permitted-Sectors-Signed.pdf#:~:text=to%20the%20end%20of%20the)
6. attachment_6_https___www_gov_ca_gov_2020_08.pdf (original URL: https://www.gov.ca.gov/2020/08/28/governor-newsom-unveils-blueprint-for-a-safer-economy-a-statewide-stringent-and-slow-plan-for-living-with-covid-19/#:~:text=SACRAMENTO%20%E2%80%93%20Governor%20Gavin%20Newsom)
7. attachment_7_https___www_cityofmontclair_or.pdf (original URL: https://www.cityofmontclair.org/december-5-2020-regional-stay-at-home-order/#:~:text=Late%20Friday%2C%20December%204%2C%202020%2C)
8. attachment_8_https___www_gov_ca_gov_2021_06.pdf (original URL: https://www.gov.ca.gov/2021/06/11/as-california-fully-reopens-governor-newsom-announces-plans-to-lift-pandemic-executive-orders/#:~:text=SACRAMENTO%20%E2%80%93%20Governor%20Gavin%20Newsom)
9. attachment_9_https___cms7files_revize_com_c.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf#:~:text=spread%20of%20COVID)
10. attachment_10_https___aagla_org_wp_content_u.pdf (original URL: https://aagla.org/wp-content/uploads/2020/06/extension-or-the-ordinance.pdf#:~:text=7)
11. attachment_11_https___aagla_org_wp_content_u.pdf (original URL: https://aagla.org/wp-content/uploads/2020/06/extension-or-the-ordinance.pdf))
12. attachment_12_https___vcportal_ventura_org_c.pdf (original URL: https://vcportal.ventura.org/covid19/docs/VC_Roadmap_to_Reopening_rev052120f.pdf#:~:text=%E2%80%A2%20March%2031%2C%202020%20%E2%80%93)
13. attachment_13_https___cms7files_revize_com_c.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf#:~:text=to%20help%20licensees%20with%20economic)
14. attachment_14_https___aagla_org_wp_content_u.pdf (original URL: https://aagla.org/wp-content/uploads/2020/06/extension-or-the-ordinance.pdf)
15. attachment_15_https___www_portofhueneme_org_.pdf (original URL: https://www.portofhueneme.org/coronavirus-update/#:~:text=May%2021%2C%202020%20%E2%80%93%20On)
16. attachment_16_https___abc7_com_ventura_count.pdf (original URL: https://abc7.com/ventura-county-beaches-july-4-2020-4th-of-weekend-open-for/6286107/#:~:text=Ventura%20County%20beaches%20to%20close)
17. attachment_17_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/VC_Public_Health_Officer_Order_10-06-2020.pdf#:~:text=OFFICER%20)
18. attachment_18_https___vcportal_ventura_org_C.pdf (original URL: https://vcportal.ventura.org/CEO/VCNC/VC_Public_Health_Officer_Order_10-06-2020.pdf#:~:text=one%20based%20on%20a%20monitoring)
19. attachment_19_https___vcportal_ventura_org_c.pdf (original URL: https://vcportal.ventura.org/covid19/docs/VC_Roadmap_to_Reopening_rev052120f.pdf#:~:text=%E2%80%A2%20May%2012%2C%202020%20%E2%80%93)
20. attachment_20_https___members_aagla_org_news.pdf (original URL: https://members.aagla.org/news/temporary-eviction-moratoriums--novel-coronavirus-covid-19#:~:text=)
21. attachment_21_https___cms7files_revize_com_c.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf#:~:text=capacity%20as%20the%20City%20of)
22. attachment_22_https___members_aagla_org_news.pdf (original URL: https://members.aagla.org/news/temporary-eviction-moratoriums--novel-coronavirus-covid-19#:~:text=Camarillo))
23. attachment_23_https___gov_ca_gov.pdf (original URL: https://gov.ca.gov)
24. attachment_24_https___cdph_ca_gov.pdf (original URL: https://cdph.ca.gov)
25. attachment_25_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2021/06/6.11.21-EO-N-07-21-signed.pdf)
26. attachment_26_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/Pages/COVID-19/Order-of-the-State-Public-Health-Officer-Beyond-Blueprint-6-11-2021.aspx))
27. attachment_27_https___vcportal_ventura_org_c.pdf (original URL: https://vcportal.ventura.org/covid19/docs/VC_Roadmap_to_Reopening_rev052120f.pdf)
28. attachment_28_https___cms7files_revize_com_c.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf)
29. attachment_29_https___members_aagla_org_news.pdf (original URL: https://members.aagla.org/news/temporary-eviction-moratoriums--novel-coronavirus-covid-19#:~:text=Camarillo)

Generated on: 2025-03-31T23:10:29.337Z